
#include <string.h>
#include <sys/param.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "esp_system.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include "esp_netif.h"

#include "lwip/err.h"
#include "lwip/sockets.h"
#include "lwip/sys.h"
#include <lwip/netdb.h>

#include "wifi.h"
#include "udp_s.h"

#define PORT_TCP                    8266
#define KEEPALIVE_IDLE              20
#define KEEPALIVE_INTERVAL          CONFIG_EXAMPLE_KEEPALIVE_INTERVAL
#define KEEPALIVE_COUNT             CONFIG_EXAMPLE_KEEPALIVE_COUNT

#define ID_BIT_LEN 16
#define USER_BIT_LEN 5
#define DEV_BIT_LEN 1
#define OPERATION_BIT_LEN 1
#define ELEMENT_BIT_LEN 3
#define VALUE_BIT_LEN 3

const uint8_t bit_lengths[] = {VALUE_BIT_LEN, ELEMENT_BIT_LEN, OPERATION_BIT_LEN, DEV_BIT_LEN, USER_BIT_LEN, ID_BIT_LEN};
size_t num_elements = sizeof(bit_lengths) / sizeof(bit_lengths[0]);

static const char *TAG = "MAIN_TCP";

int sock;

#define QUEUE_LENGTH 20      
#define STRING_SIZE 64  

#define USER_MAIN "BCR"

static void do_retransmit(const int sock)
{
    int len;
    char rx_buffer[128];
    char msg_ack[128]; 
    const char *msg_nack = "NACK"; 

    char login[128];
    char keep_alive[128];
    char pck[128];

    do{

        len = recv(sock, rx_buffer, sizeof(rx_buffer) - 1, 0);
        if (len < 0) {
            ESP_LOGE(TAG, "Error occurred during receiving: errno %d", errno);
        } else if (len == 0) {
            ESP_LOGW(TAG, "Connection closed");
        } else {
            rx_buffer[len] = 0; 
            ESP_LOGI(TAG, "Received %d bytes: %s", len, rx_buffer);

            login[0] = '\0';
            keep_alive[0] = '\0';
            msg_ack[0] = '\0';
            pck[0] = '\0';

            //sacar id_packet
            while(1)
            {
            char *ptr1 = strstr(rx_buffer, ":");
            if (!ptr1) {
                ESP_LOGE(TAG, "First ':' not found in rx_buffer");
                break;
            }
            char *ptr2 = strstr(ptr1 + 1, ":");
            if (!ptr2) {
                ESP_LOGE(TAG, "Second ':' not found after the first ':' in rx_buffer");
                break;
            }
            size_t len = ptr2 - (ptr1 + 1); // Calculate length between the colons
            if (len <= 0) {
                ESP_LOGE(TAG, "Invalid packet ID length");
                break;
            }
            char *pck_id = (char *)malloc(len + 1);
            if (!pck_id) {
                ESP_LOGE(TAG, "Memory allocation failed for packet ID");
                break;
            }

            strncpy(pck_id, ptr1 + 1, len);
            pck_id[len] = '\0'; // Null-terminate the string

            ESP_LOGI(TAG, "Packet ID: %s", pck_id);

            //crear comandos
            sprintf(login, "UABC:%s:%s:0:L:S", pck_id, USER_MAIN);
            sprintf(keep_alive, "UABC:%s:%s:0:K:S", pck_id, USER_MAIN);
            sprintf(msg_ack, "ACK:%s", pck_id);
            sprintf(pck, "%s", pck_id);
            
            free(pck_id); // Free allocated memory
            break;
            }

            //validacion de comando recibido
            if(strncmp(rx_buffer, login, strlen(login)) == 0)
            {
                int written = send(sock, msg_ack, strlen(msg_ack), 0);
                if (written < 0) {
                    ESP_LOGE(TAG, "Error occurred on sending ACK - Login: errno %d", errno);
                    return;
                }
                else 
                    ESP_LOGI(TAG, "Login Send - ACK:%s ", pck);
            }
            else if(strncmp(rx_buffer, keep_alive, strlen(keep_alive)) == 0 )
            {
                int written = send(sock, msg_ack, strlen(msg_ack), 0);
                if (written < 0) {
                    ESP_LOGE(TAG, "Error occurred on sending ACK - Keep Alive: errno %d", errno);
                    return;
                }
                else 
                    ESP_LOGI(TAG, "Keep alive Send - ACK:%s", pck);
            }
            else if((strncmp(rx_buffer, "ACK", 3) == 0 || strncmp(rx_buffer, "NACK", 4) == 0))
                    ESP_LOGW(TAG, "ACK or NACK ignored");
            else
            {
                int written = send(sock, msg_nack, strlen(msg_nack), 0);
                if (written < 0) {
                    ESP_LOGE(TAG, "Error occurred on sending NACK: errno %d", errno);
                    return;
                }
                else 
                    ESP_LOGI(TAG, "NACK send");
            }
        }

    } while (len > 0);
}

static void tcp_server_task(void *pvParameters)
{
    char addr_str[128];
    int addr_family = (int)pvParameters;
    int ip_protocol = 0;
    int keepAlive = 1;
    int keepIdle = KEEPALIVE_IDLE;
    int keepInterval = KEEPALIVE_INTERVAL;
    int keepCount = KEEPALIVE_COUNT;
    struct sockaddr_storage dest_addr;

    if (addr_family == AF_INET) {
        struct sockaddr_in *dest_addr_ip4 = (struct sockaddr_in *)&dest_addr;
        dest_addr_ip4->sin_addr.s_addr = htonl(INADDR_ANY);
        dest_addr_ip4->sin_family = AF_INET;
        dest_addr_ip4->sin_port = htons(PORT_TCP);
        ip_protocol = IPPROTO_IP;
    }

    int listen_sock = socket(addr_family, SOCK_STREAM, ip_protocol);
    if (listen_sock < 0) {
        ESP_LOGE(TAG, "Unable to create socket: errno %d", errno);
        vTaskDelete(NULL);
        return;
    }
    int opt = 1;
    setsockopt(listen_sock, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    ESP_LOGI(TAG, "Socket created");

    int err = bind(listen_sock, (struct sockaddr *)&dest_addr, sizeof(dest_addr));
    if (err != 0) {
        ESP_LOGE(TAG, "Socket unable to bind: errno %d", errno);
        ESP_LOGE(TAG, "IPPROTO: %d", addr_family);
        goto CLEAN_UP;
    }
    ESP_LOGI(TAG, "Socket bound, port %d", PORT_TCP);

    err = listen(listen_sock, 1);
    if (err != 0) {
        ESP_LOGE(TAG, "Error occurred during listen: errno %d", errno);
        goto CLEAN_UP;
    }

    while (1) {

        ESP_LOGI(TAG, "Socket listening");

        struct sockaddr_storage source_addr; // Large enough for both IPv4 or IPv6
        socklen_t addr_len = sizeof(source_addr);
        sock = accept(listen_sock, (struct sockaddr *)&source_addr, &addr_len);
        if (sock < 0) {
            ESP_LOGE(TAG, "Unable to accept connection: errno %d", errno);
            break;
        }

        // Set tcp keepalive option
        setsockopt(sock, SOL_SOCKET, SO_KEEPALIVE, &keepAlive, sizeof(int));
        setsockopt(sock, IPPROTO_TCP, TCP_KEEPIDLE, &keepIdle, sizeof(int));
        setsockopt(sock, IPPROTO_TCP, TCP_KEEPINTVL, &keepInterval, sizeof(int));
        setsockopt(sock, IPPROTO_TCP, TCP_KEEPCNT, &keepCount, sizeof(int));
        // Convert ip address to string
        if (source_addr.ss_family == PF_INET) {
            inet_ntoa_r(((struct sockaddr_in *)&source_addr)->sin_addr, addr_str, sizeof(addr_str) - 1);
        }

        ESP_LOGI(TAG, "Socket accepted ip address: %s", addr_str);

        do_retransmit(sock);

        shutdown(sock, 0);
        close(sock);
    }

CLEAN_UP:
    close(listen_sock);
    vTaskDelete(NULL);
}

void app_main(void)
{
    char command[128] = "\0";

    wifi_connection("\0", "\0");
        
    ESP_LOGE(TAG, "WIFI waiting....");
    
    while(ip_flag == 0)
        vTaskDelay(pdMS_TO_TICKS(50));

    queueHandler = xQueueCreate(QUEUE_LENGTH, STRING_SIZE);
    if(queueHandler == NULL) {
        ESP_LOGE(TAG, "Error creating queue");
        return;
    }

    xTaskCreate(tcp_server_task, "tcp_server", 4096, (void*)AF_INET, 5, NULL);

    vTaskDelay(pdMS_TO_TICKS(1000));
    xTaskCreate(udp_server_task, "udp_server_task", 4096, (void *)AF_INET, 5, &udp_server_handle);

    while(1)
    {
        //send comand from udp queue
        if(xQueueReceive(queueHandler, command, pdMS_TO_TICKS(10)))
        {
            ESP_LOGI(TAG, "Command received %s", command);
            //char *test = "UABC:BCR:R:L:test"; //patch for test, command string is null
            int written = send(sock, command, strlen(command), 0);
            if (written < 0)
                ESP_LOGE(TAG, "Error occurred during sending Command: errno %d", errno);
            else
                ESP_LOGI(TAG, "Send correctly: %s", command);
        }
        vTaskDelay(pdMS_TO_TICKS(50));
    }
}
